const express = require("express");
const routes = express.Router();


routes.get("/", (req, res) => {
    res.send("Olá Mundo Flags!")
})


module.exports = routes